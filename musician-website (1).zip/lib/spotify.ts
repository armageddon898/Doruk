// Spotify API configuration and helper functions
export const SPOTIFY_CONFIG = {
  CLIENT_ID: process.env.NEXT_PUBLIC_SPOTIFY_CLIENT_ID!,
  CLIENT_SECRET: process.env.SPOTIFY_CLIENT_SECRET!,
  REDIRECT_URI: process.env.NEXT_PUBLIC_SPOTIFY_REDIRECT_URI!,
  SCOPES: [
    "streaming",
    "user-read-email",
    "user-read-private",
    "user-read-playback-state",
    "user-modify-playback-state",
    "user-read-currently-playing",
  ].join(" "),
}

export const getSpotifyAuthUrl = () => {
  const params = new URLSearchParams({
    response_type: "code",
    client_id: SPOTIFY_CONFIG.CLIENT_ID,
    scope: SPOTIFY_CONFIG.SCOPES,
    redirect_uri: SPOTIFY_CONFIG.REDIRECT_URI,
    show_dialog: "true",
  })

  return `https://accounts.spotify.com/authorize?${params.toString()}`
}

export const getAccessToken = async (code: string) => {
  const response = await fetch("https://accounts.spotify.com/api/token", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      Authorization: `Basic ${Buffer.from(`${SPOTIFY_CONFIG.CLIENT_ID}:${SPOTIFY_CONFIG.CLIENT_SECRET}`).toString("base64")}`,
    },
    body: new URLSearchParams({
      grant_type: "authorization_code",
      code,
      redirect_uri: SPOTIFY_CONFIG.REDIRECT_URI,
    }),
  })

  return response.json()
}

export const refreshAccessToken = async (refreshToken: string) => {
  const response = await fetch("https://accounts.spotify.com/api/token", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      Authorization: `Basic ${Buffer.from(`${SPOTIFY_CONFIG.CLIENT_ID}:${SPOTIFY_CONFIG.CLIENT_SECRET}`).toString("base64")}`,
    },
    body: new URLSearchParams({
      grant_type: "refresh_token",
      refresh_token: refreshToken,
    }),
  })

  return response.json()
}

// RUDO B'nin Spotify track ID'leri (gerçek ID'ler gerekli)
export const RUDO_B_TRACKS = {
  "AGARTA INTERNATIONAL": "4uLU0hMTLkjRvRiuT5xUuh", // Örnek ID
  "Umrumda Değil": "2takcwOaAZWiXQijPHIx7B",
  "SADECE GERÇEK": "3n3Ppam7vgaVa1iaRUc9LP",
  "ARMAGEDDON FREESTYLE": "4VqPOruhp5EdPBeR92t6lQ",
  "360": "5FVd6KXrgO9B3JPmC8OPst",
  GÖKYÜZÜ: "6rqhFgbbKwnb9MLmUQDhG6",
  "YAŞA VE GÖR": "7ouMYWpwJ422jRcDASZB7P",
  "ÇETE İŞİ": "8CvRniwqxS4YBdm9cuyJD4",
  ABLUKA: "9dNCvSI3yABYGLckSjzjt5",
  "KALE İÇİ FREESTYLE": "0BK6KrCvOp3ykWYHVeVjNu",
}
