import Component from "../musician-website"

export default function Page() {
  return <Component />
}
