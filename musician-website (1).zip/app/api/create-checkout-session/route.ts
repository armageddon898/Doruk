import { type NextRequest, NextResponse } from "next/server"
import Stripe from "stripe"

export async function POST(req: NextRequest) {
  // Stripe gizli anahtarının ayarlı olduğundan emin ol
  if (!process.env.STRIPE_SECRET_KEY) {
    console.error("STRIPE_SECRET_KEY ortam değişkeni ayarlanmamış.")
    return NextResponse.json({ error: "Sunucu yapılandırma hatası: Stripe gizli anahtarı eksik." }, { status: 500 })
  }

  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
    apiVersion: "2024-04-10", // En son API versiyonunu kullan
  })

  try {
    const { priceId } = await req.json() // İstemciden priceId bekliyoruz

    if (!priceId) {
      return NextResponse.json({ error: "İstek gövdesinde Price ID gerekli." }, { status: 400 })
    }

    const session = await stripe.checkout.sessions.create({
      line_items: [
        {
          price: priceId, // İstemciden gelen priceId'yi kullan
          quantity: 1,
        },
      ],
      mode: "subscription", // Abonelik modu
      success_url: `${req.nextUrl.origin}/?success=true`, // Başarılı ödeme sonrası yönlendirilecek URL
      cancel_url: `${req.nextUrl.origin}/?canceled=true`, // İptal sonrası yönlendirilecek URL
    })

    return NextResponse.json({ sessionId: session.id, url: session.url })
  } catch (error: any) {
    console.error("Checkout oturumu oluşturulurken hata:", error)
    // Hata durumunda bile her zaman JSON yanıtı döndür
    return NextResponse.json({ error: error.message || "Checkout oturumu oluşturulamadı." }, { status: 500 })
  }
}
