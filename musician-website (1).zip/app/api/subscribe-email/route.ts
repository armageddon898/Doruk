import { type NextRequest, NextResponse } from "next/server"

export async function POST(req: NextRequest) {
  try {
    const { email } = await req.json()

    if (!email || !email.includes("@")) {
      return NextResponse.json({ error: "Geçerli bir e-posta adresi gerekli." }, { status: 400 })
    }

    // Gerçek bir uygulamada, bu e-postayı bir veritabanına kaydedersiniz
    // veya bir e-posta pazarlama servisine (Mailchimp, SendGrid vb.) gönderirsiniz.
    console.log(`Yeni abone: ${email}`)

    return NextResponse.json({ message: "Aboneliğiniz başarıyla alındı!" }, { status: 200 })
  } catch (error: any) {
    console.error("E-posta aboneliği sırasında hata:", error)
    return NextResponse.json({ error: error.message || "Abonelik işlemi başarısız oldu." }, { status: 500 })
  }
}
