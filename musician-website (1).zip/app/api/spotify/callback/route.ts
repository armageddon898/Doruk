import { type NextRequest, NextResponse } from "next/server"
import { getAccessToken } from "../../../../lib/spotify"

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const code = searchParams.get("code")
  const error = searchParams.get("error")

  if (error) {
    return NextResponse.redirect(new URL("/?error=access_denied", request.url))
  }

  if (!code) {
    return NextResponse.redirect(new URL("/?error=no_code", request.url))
  }

  try {
    const tokenData = await getAccessToken(code)

    // Store tokens securely (in a real app, use secure HTTP-only cookies)
    const response = NextResponse.redirect(new URL("/", request.url))
    response.cookies.set("spotify_access_token", tokenData.access_token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      maxAge: tokenData.expires_in,
    })

    if (tokenData.refresh_token) {
      response.cookies.set("spotify_refresh_token", tokenData.refresh_token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        maxAge: 60 * 60 * 24 * 30, // 30 days
      })
    }

    return response
  } catch (error) {
    console.error("Error getting access token:", error)
    return NextResponse.redirect(new URL("/?error=token_error", request.url))
  }
}
