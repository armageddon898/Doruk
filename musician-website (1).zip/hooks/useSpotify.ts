"use client"

import { useState, useEffect, useCallback } from "react"

interface SpotifyPlayer {
  connect: () => Promise<boolean>
  disconnect: () => void
  addListener: (event: string, callback: (data: any) => void) => void
  removeListener: (event: string, callback?: (data: any) => void) => void
  getCurrentState: () => Promise<any>
  setName: (name: string) => Promise<void>
  getVolume: () => Promise<number>
  setVolume: (volume: number) => Promise<void>
  pause: () => Promise<void>
  resume: () => Promise<void>
  togglePlay: () => Promise<void>
  seek: (position: number) => Promise<void>
  previousTrack: () => Promise<void>
  nextTrack: () => Promise<void>
}

interface Track {
  id: string
  name: string
  artists: Array<{ name: string }>
  album: {
    name: string
    images: Array<{ url: string }>
  }
  duration_ms: number
  uri: string
}

interface PlayerState {
  paused: boolean
  position: number
  duration: number
  track_window: {
    current_track: Track
  }
}

export const useSpotify = () => {
  const [player, setPlayer] = useState<SpotifyPlayer | null>(null)
  const [isReady, setIsReady] = useState(false)
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null)
  const [position, setPosition] = useState(0)
  const [duration, setDuration] = useState(0)
  const [volume, setVolume] = useState(0.5)
  const [deviceId, setDeviceId] = useState<string>("")
  const [accessToken, setAccessToken] = useState<string>("")

  // Initialize Spotify Web Playback SDK
  useEffect(() => {
    const script = document.createElement("script")
    script.src = "https://sdk.scdn.co/spotify-player.js"
    script.async = true
    document.body.appendChild(script)

    window.onSpotifyWebPlaybackSDKReady = () => {
      const token = localStorage.getItem("spotify_access_token")
      if (!token) return

      setAccessToken(token)

      const player = new window.Spotify.Player({
        name: "RUDO B Web Player",
        getOAuthToken: (cb: (token: string) => void) => {
          cb(token)
        },
        volume: 0.5,
      })

      setPlayer(player)

      player.addListener("ready", ({ device_id }: { device_id: string }) => {
        console.log("Ready with Device ID", device_id)
        setDeviceId(device_id)
        setIsReady(true)
      })

      player.addListener("not_ready", ({ device_id }: { device_id: string }) => {
        console.log("Device ID has gone offline", device_id)
        setIsReady(false)
      })

      player.addListener("player_state_changed", (state: PlayerState) => {
        if (!state) return

        setCurrentTrack(state.track_window.current_track)
        setIsPlaying(!state.paused)
        setPosition(state.position)
        setDuration(state.duration)
      })

      player.connect()
    }

    return () => {
      document.body.removeChild(script)
    }
  }, [])

  const playTrack = useCallback(
    async (trackUri: string) => {
      if (!accessToken || !deviceId) return

      try {
        await fetch(`https://api.spotify.com/v1/me/player/play?device_id=${deviceId}`, {
          method: "PUT",
          body: JSON.stringify({
            uris: [trackUri],
          }),
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${accessToken}`,
          },
        })
      } catch (error) {
        console.error("Error playing track:", error)
      }
    },
    [accessToken, deviceId],
  )

  const togglePlayback = useCallback(async () => {
    if (!player) return

    try {
      await player.togglePlay()
    } catch (error) {
      console.error("Error toggling playback:", error)
    }
  }, [player])

  const seekToPosition = useCallback(
    async (positionMs: number) => {
      if (!player) return

      try {
        await player.seek(positionMs)
      } catch (error) {
        console.error("Error seeking:", error)
      }
    },
    [player],
  )

  const setPlayerVolume = useCallback(
    async (newVolume: number) => {
      if (!player) return

      try {
        await player.setVolume(newVolume)
        setVolume(newVolume)
      } catch (error) {
        console.error("Error setting volume:", error)
      }
    },
    [player],
  )

  const login = () => {
    const authUrl = `https://accounts.spotify.com/authorize?${new URLSearchParams({
      response_type: "token",
      client_id: process.env.NEXT_PUBLIC_SPOTIFY_CLIENT_ID!,
      scope: "streaming user-read-email user-read-private user-read-playback-state user-modify-playback-state",
      redirect_uri: window.location.origin,
      show_dialog: "true",
    })}`

    window.location.href = authUrl
  }

  return {
    player,
    isReady,
    isPlaying,
    currentTrack,
    position,
    duration,
    volume,
    playTrack,
    togglePlayback,
    seekToPosition,
    setPlayerVolume,
    login,
  }
}
