// RUDO B'nin diğer şarkıları için ek kartlar

import {
  Card,
  CardHeader,
  CardContent,
  CardTitle,
  CardDescription,
  Badge,
  Button,
  Image,
  Play,
  Spotify,
} from "your-components-library" // Ensure to import all used components
;<div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mt-8">
  <Card className="bg-gray-900 border-gray-800 hover:border-purple-500 transition-all duration-300 group">
    <CardHeader className="p-0">
      <div className="relative overflow-hidden rounded-t-lg">
        <Image
          src="/images/yasa-ve-gor.png"
          alt="YAŞA VE GÖR Album"
          width={400}
          height={300}
          className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <Button size="sm" className="bg-purple-600 hover:bg-purple-700">
            <Play className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </CardHeader>
    <CardContent className="p-6">
      <CardTitle className="text-white mb-2">YAŞA VE GÖR</CardTitle>
      <CardDescription className="text-gray-400 mb-3">2022 • Single</CardDescription>
      <div className="flex items-center gap-2">
        <Spotify className="h-4 w-4 text-green-500" />
        <span className="text-sm text-gray-400">20.0K dinlenme</span>
      </div>
    </CardContent>
  </Card>

  <Card className="bg-gray-900 border-gray-800 hover:border-purple-500 transition-all duration-300 group">
    <CardHeader className="p-0">
      <div className="relative overflow-hidden rounded-t-lg">
        <Image
          src="/images/cete-isi.png"
          alt="ÇETE İŞİ Album"
          width={400}
          height={300}
          className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <Button size="sm" className="bg-purple-600 hover:bg-purple-700">
            <Play className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </CardHeader>
    <CardContent className="p-6">
      <CardTitle className="text-white mb-2">ÇETE İŞİ</CardTitle>
      <CardDescription className="text-gray-400 mb-3">2022 • Single</CardDescription>
      <div className="flex items-center gap-2">
        <Spotify className="h-4 w-4 text-green-500" />
        <span className="text-sm text-gray-400">9.1K dinlenme</span>
      </div>
    </CardContent>
  </Card>

  <Card className="bg-gray-900 border-gray-800 hover:border-purple-500 transition-all duration-300 group">
    <CardHeader className="p-0">
      <div className="relative overflow-hidden rounded-t-lg">
        <Image
          src="/images/abluka-cover.jpg"
          alt="ABLUKA Album"
          width={400}
          height={300}
          className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <Button size="sm" className="bg-purple-600 hover:bg-purple-700">
            <Play className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </CardHeader>
    <CardContent className="p-6">
      <CardTitle className="text-white mb-2">ABLUKA</CardTitle>
      <CardDescription className="text-gray-400 mb-3">2022 • Single</CardDescription>
      <div className="flex items-center gap-2">
        <Spotify className="h-4 w-4 text-green-500" />
        <span className="text-sm text-gray-400">4.4K dinlenme</span>
      </div>
    </CardContent>
  </Card>

  <Card className="bg-gray-900 border-gray-800 hover:border-purple-500 transition-all duration-300 group">
    <CardHeader className="p-0">
      <div className="relative overflow-hidden rounded-t-lg">
        <Image
          src="/images/kale-ici-freestyle.png"
          alt="KALE İÇİ FREESTYLE Album"
          width={400}
          height={300}
          className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <Button size="sm" className="bg-purple-600 hover:bg-purple-700">
            <Play className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </CardHeader>
    <CardContent className="p-6">
      <CardTitle className="text-white mb-2">KALE İÇİ FREESTYLE</CardTitle>
      <CardDescription className="text-gray-400 mb-3">2022 • Freestyle</CardDescription>
      <div className="flex items-center gap-2">
        <Spotify className="h-4 w-4 text-green-500" />
        <span className="text-sm text-gray-400">1K dinlenme</span>
      </div>
      <Badge className="mt-3 bg-red-600 hover:bg-red-700">Underground</Badge>
    </CardContent>
  </Card>
</div>
