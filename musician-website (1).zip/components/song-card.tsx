"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Play, AirplayIcon as Spotify } from "lucide-react"
import { useSpotify } from "../hooks/useSpotify"
import { RUDO_B_TRACKS } from "../lib/spotify"
import Image from "next/image"

interface SongCardProps {
  title: string
  description: string
  plays: string
  badge?: string
  imageAlt: string
}

export function SongCard({ title, description, plays, badge, imageAlt }: SongCardProps) {
  const { playTrack, isReady } = useSpotify()

  const handlePlay = () => {
    const trackId = RUDO_B_TRACKS[title as keyof typeof RUDO_B_TRACKS]
    if (trackId && isReady) {
      playTrack(`spotify:track:${trackId}`)
    } else {
      // Fallback to Spotify web player
      window.open(`https://open.spotify.com/search/${encodeURIComponent(title + " RUDO B")}`, "_blank")
    }
  }

  return (
    <Card className="bg-gray-900 border-gray-800 hover:border-red-500 transition-all duration-300 group">
      <CardHeader className="p-0">
        <div className="relative overflow-hidden rounded-t-lg">
          <Image
            src="/placeholder.svg?height=300&width=400"
            alt={imageAlt}
            width={400}
            height={300}
            className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
          />
          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
            <Button size="sm" className="bg-red-600 hover:bg-red-700" onClick={handlePlay}>
              <Play className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <CardTitle className="text-white mb-2">{title}</CardTitle>
        <CardDescription className="text-gray-400 mb-3">{description}</CardDescription>
        <div className="flex items-center gap-2 mb-3">
          <Spotify className="h-4 w-4 text-green-500" />
          <span className="text-sm text-gray-400">{plays} dinlenme</span>
        </div>
        {badge && <Badge className="bg-red-600 hover:bg-red-700">{badge}</Badge>}
      </CardContent>
    </Card>
  )
}
