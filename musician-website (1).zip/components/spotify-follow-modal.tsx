"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { AirplayIcon as Spotify, Heart, ArrowRight, X } from "lucide-react"
import Image from "next/image"

interface SpotifyFollowModalProps {
  isOpen: boolean
  onClose: () => void
  spotifyUrl: string
  songTitle?: string
}

export function SpotifyFollowModal({ isOpen, onClose, spotifyUrl, songTitle }: SpotifyFollowModalProps) {
  const [countdown, setCountdown] = useState(5)
  const [autoRedirect, setAutoRedirect] = useState(true)

  useEffect(() => {
    if (isOpen && autoRedirect && countdown > 0) {
      const timer = setTimeout(() => {
        setCountdown(countdown - 1)
      }, 1000)
      return () => clearTimeout(timer)
    } else if (isOpen && autoRedirect && countdown === 0) {
      handleContinue()
    }
  }, [isOpen, countdown, autoRedirect])

  const handleContinue = () => {
    window.open(spotifyUrl, "_blank")
    onClose()
  }

  const handleStopCountdown = () => {
    setAutoRedirect(false)
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-red-500 text-white max-w-md mx-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Spotify className="h-6 w-6 text-green-500" />
            Spotify'a Yönlendiriliyorsun
          </DialogTitle>
          <DialogDescription className="text-gray-400">
            RUDO B'yi takip etmek için Spotify'a yönlendiriliyorsun
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* RUDO B Avatar */}
          <div className="text-center">
            <div className="relative mx-auto w-20 h-20 rounded-full overflow-hidden border-2 border-red-500">
              <Image
                src="/placeholder.svg?height=80&width=80"
                alt="RUDO B"
                width={80}
                height={80}
                className="object-cover"
              />
            </div>
            <h3 className="text-lg font-bold mt-2 bg-gradient-to-r from-red-400 to-red-600 bg-clip-text text-transparent">
              RUDO B
            </h3>
          </div>

          {/* Follow Reminder */}
          <div className="bg-gradient-to-r from-green-600/20 to-green-500/20 rounded-lg p-4 border border-green-500/30">
            <div className="flex items-center gap-3 mb-3">
              <Heart className="h-5 w-5 text-red-500" />
              <span className="font-semibold">Takip Etmeyi Unutma!</span>
            </div>
            <p className="text-sm text-gray-300 mb-3">
              {songTitle ? `"${songTitle}" şarkısını dinlerken` : "Spotify'da"} RUDO B'yi takip etmeyi unutma!
            </p>
            <div className="flex items-center gap-2 text-xs text-green-400">
              <Spotify className="h-4 w-4" />
              <span>Takip Et butonuna tıkla</span>
              <ArrowRight className="h-3 w-3" />
              <span>Yeni şarkılardan haberdar ol</span>
            </div>
          </div>

          {/* Visual Guide */}
          <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
            <h4 className="font-semibold mb-2 text-sm">Nasıl Takip Edilir:</h4>
            <div className="space-y-2 text-xs text-gray-400">
              <div className="flex items-center gap-2">
                <span className="bg-red-600 text-white rounded-full w-4 h-4 flex items-center justify-center text-xs">
                  1
                </span>
                <span>RUDO B'nin profil sayfasını aç</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="bg-red-600 text-white rounded-full w-4 h-4 flex items-center justify-center text-xs">
                  2
                </span>
                <span>Yeşil "Takip Et" butonuna tıkla</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="bg-red-600 text-white rounded-full w-4 h-4 flex items-center justify-center text-xs">
                  3
                </span>
                <span>Yeni şarkılardan otomatik haberdar ol!</span>
              </div>
            </div>
          </div>

          {/* Countdown */}
          {autoRedirect && (
            <div className="text-center">
              <div className="bg-green-600 text-white rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-2 text-xl font-bold">
                {countdown}
              </div>
              <p className="text-sm text-gray-400">saniye sonra otomatik yönlendirileceksin</p>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleStopCountdown}
                className="text-gray-400 hover:text-white mt-1"
              >
                Durdur
              </Button>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-3">
            <Button onClick={handleContinue} className="flex-1 bg-green-600 hover:bg-green-700 text-white">
              <Spotify className="mr-2 h-4 w-4" />
              Spotify'a Git
            </Button>
            <Button
              onClick={onClose}
              variant="outline"
              className="border-gray-600 text-gray-400 hover:text-white bg-transparent"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
