"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Play, Pause, SkipBack, SkipForward, Volume2, AirplayIcon as Spotify } from "lucide-react"
import { useSpotify } from "../hooks/useSpotify"
import Image from "next/image"

export function SpotifyPlayer() {
  const {
    isReady,
    isPlaying,
    currentTrack,
    position,
    duration,
    volume,
    togglePlayback,
    seekToPosition,
    setPlayerVolume,
    login,
  } = useSpotify()

  const [showPlayer, setShowPlayer] = useState(false)

  useEffect(() => {
    // Check if user has Spotify token
    const token = localStorage.getItem("spotify_access_token")
    if (token) {
      setShowPlayer(true)
    }
  }, [])

  const formatTime = (ms: number) => {
    const minutes = Math.floor(ms / 60000)
    const seconds = Math.floor((ms % 60000) / 1000)
    return `${minutes}:${seconds.toString().padStart(2, "0")}`
  }

  if (!showPlayer) {
    return (
      <div className="fixed bottom-4 right-4 z-50">
        <Button onClick={login} className="bg-green-600 hover:bg-green-700 text-white flex items-center gap-2">
          <Spotify className="h-5 w-5" />
          Spotify ile Bağlan
        </Button>
      </div>
    )
  }

  if (!isReady) {
    return (
      <div className="fixed bottom-0 left-0 right-0 bg-gray-900 border-t border-gray-800 p-4 z-50">
        <div className="flex items-center justify-center">
          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-green-500"></div>
          <span className="ml-2 text-white">Spotify Player Yükleniyor...</span>
        </div>
      </div>
    )
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-gray-900 border-t border-gray-800 p-4 z-50">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between">
          {/* Current Track Info */}
          <div className="flex items-center gap-4 flex-1">
            {currentTrack && (
              <>
                <Image
                  src={currentTrack.album.images[0]?.url || "/placeholder.svg?height=60&width=60"}
                  alt={currentTrack.album.name}
                  width={60}
                  height={60}
                  className="rounded-lg"
                />
                <div>
                  <h4 className="text-white font-semibold">{currentTrack.name}</h4>
                  <p className="text-gray-400 text-sm">
                    {currentTrack.artists.map((artist) => artist.name).join(", ")}
                  </p>
                </div>
              </>
            )}
          </div>

          {/* Playback Controls */}
          <div className="flex flex-col items-center gap-2 flex-1">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" className="text-white hover:text-green-400">
                <SkipBack className="h-5 w-5" />
              </Button>

              <Button onClick={togglePlayback} className="bg-green-600 hover:bg-green-700 rounded-full w-10 h-10 p-0">
                {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5 ml-0.5" />}
              </Button>

              <Button variant="ghost" size="sm" className="text-white hover:text-green-400">
                <SkipForward className="h-5 w-5" />
              </Button>
            </div>

            {/* Progress Bar */}
            <div className="flex items-center gap-2 w-full max-w-md">
              <span className="text-xs text-gray-400 w-10">{formatTime(position)}</span>
              <Slider
                value={[position]}
                max={duration}
                step={1000}
                onValueChange={([value]) => seekToPosition(value)}
                className="flex-1"
              />
              <span className="text-xs text-gray-400 w-10">{formatTime(duration)}</span>
            </div>
          </div>

          {/* Volume Control */}
          <div className="flex items-center gap-2 flex-1 justify-end">
            <Volume2 className="h-4 w-4 text-gray-400" />
            <Slider
              value={[volume * 100]}
              max={100}
              step={1}
              onValueChange={([value]) => setPlayerVolume(value / 100)}
              className="w-24"
            />
          </div>
        </div>
      </div>
    </div>
  )
}
