"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  Calendar,
  MapPin,
  Music,
  Play,
  Instagram,
  Twitter,
  Youtube,
  AirplayIcon as Spotify,
  CheckCircle,
} from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { SpotifyFollowModal } from "./components/spotify-follow-modal"

export default function Component() {
  const [showSpotifyModal, setShowSpotifyModal] = useState(false)
  const [spotifyUrl, setSpotifyUrl] = useState("")
  const [currentSong, setCurrentSong] = useState("")
  const [email, setEmail] = useState("") // E-posta input değeri için state
  const [isSubmitting, setIsSubmitting] = useState(false) // Yüklenme durumu için state
  const [isSubscribed, setIsSubscribed] = useState(false) // Abonelik başarılı durumu için state

  const handleSpotifyClick = (url: string, songTitle?: string) => {
    setSpotifyUrl(url)
    setCurrentSong(songTitle || "")
    setShowSpotifyModal(true)
  }

  const songs = [
    { title: "AGARTA INTERNATIONAL", year: 2024, spotifyId: "4uLU0hMTLkjRvRiuT5xUuh" },
    { title: "Umrumda Değil", year: 2023, spotifyId: "2takcwOaAZWiXQijPHIx7B" },
    { title: "SADECE GERÇEK", year: 2023, spotifyId: "3n3Ppam7vgaVa1iaRUc9LP" },
    { title: "ARMAGEDDON FREESTYLE", year: 2023, spotifyId: "4VqPOruhp5EdPBeR92t6lQ" },
    { title: "360", year: 2023, spotifyId: "5FVd6KXrgO9B3JPmC8OPst" },
    { title: "GÖKYÜZÜ", year: 2023, spotifyId: "7ouMYWpwJ422jRcDASZB7P" },
    { title: "ABLUKA", year: 2022, spotifyId: "9dNCvSI3yABYGLckSjzjt5" },
  ]

  const latestSong = songs.sort((a, b) => b.year - a.year)[0]

  const handlePlayLatestSong = () => {
    const latestSongTitle = "AGARTA INTERNATIONAL"
    const spotifyUrl = "https://open.spotify.com/search/RUDO%20B%20AGARTA%20INTERNATIONAL"
    handleSpotifyClick(spotifyUrl, latestSongTitle)
  }

  const handlePlaySong = (songName: string) => {
    const searchQuery = `RUDO B ${songName}`.replace(/\s+/g, "%20")
    const spotifyUrl = `https://open.spotify.com/search/${searchQuery}`
    handleSpotifyClick(spotifyUrl, songName)
  }

  const openSpotifyProfile = () => {
    handleSpotifyClick("https://open.spotify.com/search/RUDO%20B")
  }

  // E-posta abonelik fonksiyonu
  const handleSubscribe = async () => {
    if (!email) {
      alert("Lütfen e-posta adresinizi girin.")
      return
    }

    setIsSubmitting(true)
    setIsSubscribed(false) // Yeni denemede önceki başarıyı sıfırla

    try {
      const response = await fetch("/api/subscribe-email", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        console.error("Abonelik hatası:", errorData.error)
        alert(`Abonelik başarısız oldu: ${errorData.error}`)
        return
      }

      // Başarılı olursa
      setIsSubscribed(true)
      setEmail("") // Input'u temizle
      // İsteğe bağlı: Birkaç saniye sonra başarı mesajını gizle
      setTimeout(() => setIsSubscribed(false), 5000)
    } catch (error) {
      console.error("Abonelik sırasında beklenmedik bir hata oluştu:", error)
      alert("Abonelik sırasında beklenmedik bir hata oluştu.")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="flex flex-col min-h-screen bg-black text-white">
      {/* Header */}
      <header className="fixed top-0 w-full z-50 bg-black/80 backdrop-blur-md border-b border-gray-800">
        <div className="container mx-auto px-4 lg:px-6 h-16 flex items-center justify-between">
          <Link
            href="/"
            className="text-2xl font-bold bg-gradient-to-r from-red-400 to-red-600 bg-clip-text text-transparent"
          >
            RUDO B
          </Link>
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="#home" className="text-sm font-medium hover:text-red-400 transition-colors">
              Ana Sayfa
            </Link>
            <Link href="#music" className="text-sm font-medium hover:text-red-400 transition-colors">
              Müzik
            </Link>
            <Link href="#tours" className="text-sm font-medium hover:text-red-400 transition-colors">
              Konserler
            </Link>
            <Link href="#about" className="text-sm font-medium hover:text-red-400 transition-colors">
              Hakkımda
            </Link>
            <Link href="#contact" className="text-sm font-medium hover:text-red-400 transition-colors">
              İletişim
            </Link>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-red-900/20 to-red-800/20 z-10" />
        <Image
          src="/placeholder.svg?height=1080&width=1920"
          alt="Concert Stage"
          fill
          className="object-cover"
          priority
        />
        <div className="relative z-20 text-center px-4 max-w-4xl mx-auto">
          <h1 className="text-6xl md:text-8xl font-bold mb-6 bg-gradient-to-r from-red-400 via-red-500 to-red-600 bg-clip-text text-transparent">
            RUDO B
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-gray-300">Hip-Hop ve Rap Müziğin Güçlü Sesi</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800"
              onClick={handlePlayLatestSong}
            >
              <Play className="mr-2 h-5 w-5" />
              Son Şarkımı Dinle
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-red-400 text-red-400 hover:bg-red-400 hover:text-black bg-transparent"
              onClick={() => window.open("https://biletino.com/tr/performer/kj2wi3zaii-rudo-b/", "_blank")}
            >
              Konser Biletleri
            </Button>
          </div>
          <div className="mt-6">
            <Button
              onClick={openSpotifyProfile}
              className="bg-green-600 hover:bg-green-700 text-white flex items-center gap-2 mx-auto"
            >
              <Spotify className="h-5 w-5" />
              Spotify'da Takip Et
            </Button>
          </div>
        </div>
      </section>

      {/* Music Section */}
      <section id="music" className="py-20 px-4">
        <div className="container mx-auto max-w-7xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-red-400 to-red-600 bg-clip-text text-transparent">
              Müziklerim
            </h2>
            <p className="text-gray-400 text-lg">En sevilen şarkılarım ve son çıkan albümlerim</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            <Card className="bg-gray-900 border-gray-800 hover:border-red-500 transition-all duration-300 group max-w-sm mx-auto w-full">
              <CardHeader className="p-0">
                <div className="relative overflow-hidden rounded-t-lg aspect-square">
                  <Image
                    src="/images/agarta-international-cover.jpg"
                    alt="AGARTA INTERNATIONAL Album"
                    fill
                    className="object-contain bg-gray-800 group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <Button
                      size="sm"
                      className="bg-red-600 hover:bg-red-700"
                      onClick={() => handlePlaySong("AGARTA INTERNATIONAL")}
                    >
                      <Play className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-4">
                <CardTitle className="text-white mb-2 text-lg">AGARTA INTERNATIONAL</CardTitle>
                <CardDescription className="text-gray-400 mb-3 text-sm">2024 • Single</CardDescription>
                <div className="flex items-center gap-2 mb-3">
                  <Spotify className="h-4 w-4 text-green-500" />
                  <span className="text-sm text-gray-400">182.7K dinlenme</span>
                </div>
                <Badge className="bg-red-600 hover:bg-red-700 text-xs">Hit</Badge>
              </CardContent>
            </Card>

            <Card className="bg-gray-900 border-gray-800 hover:border-red-500 transition-all duration-300 group max-w-sm mx-auto w-full">
              <CardHeader className="p-0">
                <div className="relative overflow-hidden rounded-t-lg aspect-square">
                  <Image
                    src="/images/umrumda-degil-cover.jpg"
                    alt="Umrumda Değil Album"
                    fill
                    className="object-contain bg-gray-800 group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <Button
                      size="sm"
                      className="bg-red-600 hover:bg-red-700"
                      onClick={() => handlePlaySong("Umrumda Değil")}
                    >
                      <Play className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-4">
                <CardTitle className="text-white mb-2 text-lg">Umrumda Değil</CardTitle>
                <CardDescription className="text-gray-400 mb-3 text-sm">2023 • Single</CardDescription>
                <div className="flex items-center gap-2">
                  <Spotify className="h-4 w-4 text-green-500" />
                  <span className="text-sm text-gray-400">85.6K dinlenme</span>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-900 border-gray-800 hover:border-red-500 transition-all duration-300 group max-w-sm mx-auto w-full">
              <CardHeader className="p-0">
                <div className="relative overflow-hidden rounded-t-lg aspect-square">
                  <Image
                    src="/images/sadece-gercek-cover.jpg"
                    alt="SADECE GERÇEK Album"
                    fill
                    className="object-contain bg-gray-800 group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <Button
                      size="sm"
                      className="bg-red-600 hover:bg-red-700"
                      onClick={() => handlePlaySong("SADECE GERÇEK")}
                    >
                      <Play className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-4">
                <CardTitle className="text-white mb-2 text-lg">SADECE GERÇEK</CardTitle>
                <CardDescription className="text-gray-400 mb-3 text-sm">2023 • Single</CardDescription>
                <div className="flex items-center gap-2">
                  <Spotify className="h-4 w-4 text-green-500" />
                  <span className="text-sm text-gray-400">36.9K dinlenme</span>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-900 border-gray-800 hover:border-red-500 transition-all duration-300 group max-w-sm mx-auto w-full">
              <CardHeader className="p-0">
                <div className="relative overflow-hidden rounded-t-lg aspect-square">
                  <Image
                    src="/images/armageddon-cover.jpg"
                    alt="ARMAGEDDON FREESTYLE Album"
                    fill
                    className="object-contain bg-gray-800 group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <Button
                      size="sm"
                      className="bg-red-600 hover:bg-red-700"
                      onClick={() => handlePlaySong("ARMAGEDDON FREESTYLE")}
                    >
                      <Play className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-4">
                <CardTitle className="text-white mb-2 text-lg">ARMAGEDDON FREESTYLE</CardTitle>
                <CardDescription className="text-gray-400 mb-3 text-sm">2023 • Freestyle</CardDescription>
                <div className="flex items-center gap-2">
                  <Spotify className="h-4 w-4 text-green-500" />
                  <span className="text-sm text-gray-400">25.3K dinlenme</span>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-900 border-gray-800 hover:border-red-500 transition-all duration-300 group max-w-sm mx-auto w-full">
              <CardHeader className="p-0">
                <div className="relative overflow-hidden rounded-t-lg aspect-square">
                  <Image
                    src="/images/abluka-cover.jpg"
                    alt="ABLUKA Album"
                    fill
                    className="object-contain bg-gray-800 group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <Button size="sm" className="bg-red-600 hover:bg-red-700" onClick={() => handlePlaySong("ABLUKA")}>
                      <Play className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-4">
                <CardTitle className="text-white mb-2 text-lg">ABLUKA</CardTitle>
                <CardDescription className="text-gray-400 mb-3 text-sm">2022 • Single</CardDescription>
                <div className="flex items-center gap-2 mb-3">
                  <Spotify className="h-4 w-4 text-green-500" />
                  <span className="text-sm text-gray-400">4.4K dinlenme</span>
                </div>
                <Badge className="bg-red-600 hover:bg-red-700 text-xs">Underground</Badge>
              </CardContent>
            </Card>

            <Card className="bg-gray-900 border-gray-800 hover:border-red-500 transition-all duration-300 group max-w-sm mx-auto w-full">
              <CardHeader className="p-0">
                <div className="relative overflow-hidden rounded-t-lg aspect-square">
                  <Image
                    src="/images/360-cover.jpg"
                    alt="360 Album"
                    fill
                    className="object-contain bg-gray-800 group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <Button size="sm" className="bg-red-600 hover:bg-red-700" onClick={() => handlePlaySong("360")}>
                      <Play className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-4">
                <CardTitle className="text-white mb-2 text-lg">360</CardTitle>
                <CardDescription className="text-gray-400 mb-3 text-sm">2023 • Single</CardDescription>
                <div className="flex items-center gap-2">
                  <Spotify className="h-4 w-4 text-green-500" />
                  <span className="text-sm text-gray-400">23.5K dinlenme</span>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-900 border-gray-800 hover:border-red-500 transition-all duration-300 group max-w-sm mx-auto w-full">
              <CardHeader className="p-0">
                <div className="relative overflow-hidden rounded-t-lg aspect-square">
                  <Image
                    src="/images/gokyuzu-cover.jpg"
                    alt="GÖKYÜZÜ Album"
                    fill
                    className="object-contain bg-gray-800 group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <Button size="sm" className="bg-red-600 hover:bg-red-700" onClick={() => handlePlaySong("GÖKYÜZÜ")}>
                      <Play className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-4">
                <CardTitle className="text-white mb-2 text-lg">GÖKYÜZÜ</CardTitle>
                <CardDescription className="text-gray-400 mb-3 text-sm">2023 • Single</CardDescription>
                <div className="flex items-center gap-2 mb-3">
                  <Spotify className="h-4 w-4 text-green-500" />
                  <span className="text-sm text-gray-400">21.9K dinlenme</span>
                </div>
                <Badge className="bg-blue-600 hover:bg-blue-700 text-xs">Collaboration</Badge>
              </CardContent>
            </Card>
          </div>

          {/* Spotify CTA Section */}
          <div className="text-center mt-16">
            <div className="bg-gradient-to-r from-green-600/20 to-green-500/20 rounded-2xl p-8 border border-green-500/30">
              <Spotify className="h-16 w-16 text-green-500 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-white mb-4">Tüm Şarkılarımı Dinle</h3>
              <p className="text-gray-300 mb-6">
                Spotify'da tüm şarkılarıma, playlist'lerime ve yeni çıkan parçalarıma ulaşabilirsin!
              </p>
              <Button
                onClick={openSpotifyProfile}
                className="bg-green-600 hover:bg-green-700 text-white text-lg px-8 py-3"
              >
                <Spotify className="mr-2 h-5 w-5" />
                Spotify'da Aç
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Tour Dates */}
      <section id="tours" className="py-20 px-4 bg-gray-900/50">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-red-400 to-red-600 bg-clip-text text-transparent">
              Konserler
            </h2>
            <p className="text-gray-400 text-lg">Canlı performanslarımda buluşalım</p>
          </div>

          <div className="space-y-6">
            <Card className="bg-gray-800 border-gray-700 hover:border-red-500 transition-colors">
              <CardContent className="p-6">
                <div className="flex flex-col lg:flex-row gap-6">
                  <div className="lg:w-1/3">
                    <div className="relative overflow-hidden rounded-lg">
                      <Image
                        src="/images/agarta-international-clean.jpg"
                        alt="AGARTA INTERNATIONAL VOL.1 Concert Poster"
                        width={300}
                        height={400}
                        className="w-full h-64 lg:h-full object-cover"
                      />
                    </div>
                  </div>
                  <div className="lg:w-2/3 flex flex-col justify-between">
                    <div>
                      <h3 className="text-2xl font-bold text-white mb-3">AGARTA INTERNATIONAL VOL.1</h3>
                      <p className="text-gray-300 mb-4">
                        Hip-hop sahnesinin en güçlü isimlerinin bir araya geldiği özel etkinlik. RUDO B ve 15+ sanatçı
                        aynı sahnede!
                      </p>
                      <div className="space-y-2 mb-4">
                        <div className="flex items-center gap-2 text-gray-400">
                          <Calendar className="h-4 w-4" />
                          <span>11 Mayıs 2024 • 20:30</span>
                        </div>
                        <div className="flex items-center gap-2 text-gray-400">
                          <MapPin className="h-4 w-4" />
                          <span>Bornova, İzmir</span>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-2 mb-4">
                        <Badge className="bg-purple-600 hover:bg-purple-700 text-xs">Multi-Artist</Badge>
                        <Badge className="bg-red-600 hover:bg-red-700 text-xs">RUDO B</Badge>
                        <Badge className="bg-blue-600 hover:bg-blue-700 text-xs">Hip-Hop</Badge>
                      </div>
                    </div>
                    <Button
                      className="bg-red-600 hover:bg-red-700 w-full lg:w-auto"
                      onClick={() => window.open("https://biletino.com/tr/performer/kj2wi3zaii-rudo-b/", "_blank")}
                    >
                      Bilet Al
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-red-400 to-red-600 bg-clip-text text-transparent">
                Hakkımda
              </h2>
              <p className="text-gray-300 text-lg mb-6 leading-relaxed">
                Merhaba, ben Rudo B. Hip-hop ve rap müziğin güçlü temsilcilerinden biriyim ve 10 yaşından beri bu
                kültürün içindeyim. Sokak kültürü, gerçek hayat hikayeleri ve güçlü sözlerle dinleyicilerime ulaşmaya
                çalışıyorum.
              </p>
              <p className="text-gray-300 text-lg mb-8 leading-relaxed">
                Şarkılarımda sokağın gerçeklerini, hayallerimi, mücadelelerimi ve başarı hikayelerimi anlatıyorum.
                Amacım müziğimle gençlere ilham vermek ve onlara hayallerinin peşinden gitmeleri gerektiğini göstermek.
                Her sahne performansımda enerjimi dinleyicilerimle paylaşıyorum.
              </p>
              <div className="flex gap-4">
                <Button className="bg-red-600 hover:bg-red-700">
                  <Music className="mr-2 h-4 w-4" />
                  Diskografi
                </Button>
                <Button
                  variant="outline"
                  className="border-red-400 text-red-400 hover:bg-red-400 hover:text-black bg-transparent"
                >
                  Röportajlar
                </Button>
              </div>
            </div>
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-red-600/20 to-red-700/20 rounded-2xl transform rotate-3"></div>
              <Image
                src="/images/rudo-b-live-performance.jpg"
                alt="RUDO B Portrait"
                width={500}
                height={600}
                className="relative rounded-2xl object-contain w-full h-auto max-h-[400px]"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-red-900/20 to-red-800/20">
        <div className="container mx-auto max-w-4xl text-center">
          <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-red-400 to-red-600 bg-clip-text text-transparent">
            Haberdar Ol
          </h2>
          <p className="text-gray-300 text-lg mb-8">
            Yeni parçalarım, battle duyurularım ve özel mixtape'lerden ilk sen haberdar ol
          </p>
          <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
            <Input
              type="email"
              placeholder="E-posta adresin"
              className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-400"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={isSubmitting || isSubscribed}
            />
            <Button
              className="bg-red-600 hover:bg-red-700 whitespace-nowrap"
              onClick={handleSubscribe}
              disabled={isSubmitting || isSubscribed}
            >
              {isSubmitting ? "Gönderiliyor..." : isSubscribed ? "Abone Olundu!" : "Abone Ol"}
            </Button>
          </div>
          {isSubscribed && (
            <div className="mt-4 flex items-center justify-center text-green-500 font-semibold">
              <CheckCircle className="h-5 w-5 mr-2" />
              Aboneliğiniz başarıyla alındı!
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 py-12 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="text-center md:text-left">
              <h3 className="text-2xl font-bold bg-gradient-to-r from-red-400 to-red-600 bg-clip-text text-transparent mb-2">
                RUDO B
              </h3>
              <p className="text-gray-400">Hip-Hop ve Rap müziğin güçlü sesi</p>
            </div>

            <div className="flex gap-6">
              <Link href="#" className="text-gray-400 hover:text-red-400 transition-colors">
                <Instagram className="h-6 w-6" />
                <span className="sr-only">Instagram</span>
              </Link>
              <Link href="#" className="text-gray-400 hover:text-red-400 transition-colors">
                <Twitter className="h-6 w-6" />
                <span className="sr-only">Twitter</span>
              </Link>
              <Link href="#" className="text-gray-400 hover:text-red-400 transition-colors">
                <Youtube className="h-6 w-6" />
                <span className="sr-only">YouTube</span>
              </Link>
              <Link
                href="#"
                className="text-gray-400 hover:text-red-400 transition-colors"
                onClick={(e) => {
                  e.preventDefault()
                  openSpotifyProfile()
                }}
              >
                <Spotify className="h-6 w-6" />
                <span className="sr-only">Spotify</span>
              </Link>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center">
            <p className="text-gray-400 text-sm">© {new Date().getFullYear()} RUDO B. Tüm hakları saklıdır.</p>
          </div>
        </div>
      </footer>

      {/* Spotify Follow Modal */}
      <SpotifyFollowModal
        isOpen={showSpotifyModal}
        onClose={() => setShowSpotifyModal(false)}
        spotifyUrl={spotifyUrl}
        songTitle={currentSong}
      />
    </div>
  )
}
